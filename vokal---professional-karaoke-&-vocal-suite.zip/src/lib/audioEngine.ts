import * as Tone from 'tone';

export class AudioEngine {
  private player: Tone.Player | null = null;
  private pitchShift: Tone.PitchShift | null = null;
  private recorder: Tone.Recorder | null = null;
  private mic: Tone.UserMedia | null = null;
  private analyser: Tone.Analyser | null = null;

  constructor() {
    this.pitchShift = new Tone.PitchShift(0).toDestination();
    this.analyser = new Tone.Analyser('waveform', 1024);
    this.mic = new Tone.UserMedia();
  }

  async init(url: string) {
    try {
      console.log("AudioEngine.init: starting for URL:", url);
      this.startOffset = 0;
      this.startTime = 0;
      
      // Ensure context is running - resume if it was suspended
      const ctx = Tone.getContext();
      console.log("AudioEngine.init: current Tone context state:", ctx.state);
      if (ctx.state !== 'running') {
        console.log("AudioEngine.init: Tone context is not running, attempting to resume...");
        await ctx.resume();
        console.log("AudioEngine.init: after resume attempt, state is:", ctx.state);
      }

      if (this.player) {
        console.log("AudioEngine.init: disposing existing player");
        this.player.stop();
        this.player.dispose();
        this.player = null;
      }

      return new Promise<void>((resolve, reject) => {
        let isDone = false;
        const timeout = setTimeout(() => {
          if (!isDone) {
            isDone = true;
            console.error("AudioEngine.init: timeout loading:", url);
            reject(new Error("Audio load timeout (15s)"));
          }
        }, 15000);

        this.player = new Tone.Player({
          url,
          onload: () => {
            if (isDone) return;
            isDone = true;
            clearTimeout(timeout);
            const dur = this.getDuration();
            console.log("AudioEngine.init: buffer loaded successfully. Duration:", dur);
            resolve();
          },
          onerror: (err) => {
            if (isDone) return;
            isDone = true;
            clearTimeout(timeout);
            console.error("AudioEngine.init: Tone.Player load error - URL likely failed:", url, err);
            reject(err);
          }
        }).connect(this.pitchShift!);
      });
    } catch (error) {
      console.error("AudioEngine.init error:", error);
      throw error;
    }
  }

  private startOffset: number = 0;

  private startTime: number = 0;

  play() {
    console.log("AudioEngine: play() called. Player status:", this.player ? "Initialized" : "Missing", "Loaded:", this.player?.loaded, "State:", this.player?.state, "Context state:", Tone.getContext().state);
    
    if (this.player && this.player.loaded) {
      if (this.player.state === 'stopped') {
        try {
          if (Tone.getContext().state !== 'running') {
            console.warn("AudioEngine: Context not running during play(), attempting to resume...");
            Tone.getContext().resume();
          }
          
          this.startTime = Tone.now();
          console.log("AudioEngine: Starting player at", this.startOffset, "Tone.now() is", this.startTime);
          this.player.start(this.startTime, this.startOffset);
          
          // Force a state check in a bit
          setTimeout(() => {
            console.log("AudioEngine: Player state after 100ms:", this.player?.state);
          }, 100);
        } catch (e) {
          console.error("AudioEngine: Failed to start player:", e);
        }
      } else {
        console.log("AudioEngine: Player already started");
      }
    } else {
      console.warn("AudioEngine: Player not ready or buffer not loaded");
    }
  }

  stop() {
    if (this.player && this.player.state === 'started') {
      this.player.stop();
      console.log("AudioEngine: Player stopped");
    }
  }

  getDuration() {
    return this.player?.buffer?.duration || 0;
  }

  getCurrentTime() {
    if (this.player && this.player.loaded && this.player.state === 'started') {
      try {
        const now = Tone.now();
        const elapsed = (now - this.startTime) * this.player.playbackRate;
        const total = this.startOffset + elapsed;
        
        // Log periodically every few seconds
        if (Math.floor(total * 10) % 50 === 0) {
          // console.log("AudioEngine: Timing debug - now:", now, "start:", this.startTime, "offset:", this.startOffset, "total:", total);
        }
        
        return isNaN(total) ? 0 : total;
      } catch (e) {
        return this.startOffset;
      }
    }
    return this.startOffset;
  }

  seekTo(time: number) {
    this.startOffset = time;
    if (this.player && this.player.loaded) {
      if (this.player.state === 'started') {
        this.player.stop();
        this.player.start(Tone.now(), time);
      }
    }
  }

  setPitch(semitones: number) {
    if (this.pitchShift) this.pitchShift.pitch = semitones;
  }

  setTempo(rate: number) {
    if (this.player) this.player.playbackRate = rate;
  }

  async startRecording() {
    if (!this.mic) return;
    try {
      await this.mic.open();
      this.recorder = new Tone.Recorder();
      this.mic.connect(this.recorder);
      this.mic.connect(this.analyser!);
      this.recorder.start();
    } catch (error) {
      console.error("Recording start failed:", error);
      throw error;
    }
  }

  async stopRecording(): Promise<Blob | null> {
    if (!this.recorder || this.recorder.state !== 'started') {
      console.warn("Recorder not started");
      return null;
    }
    try {
      const blob = await this.recorder.stop();
      this.mic?.close();
      this.mic?.disconnect();
      return blob;
    } catch (error) {
      console.error("Recording stop failed:", error);
      return null;
    }
  }

  getPitch(): number | null {
    if (!this.analyser) return null;
    const buffer = this.analyser.getValue() as Float32Array;
    return this.detectPitch(buffer);
  }

  private detectPitch(buffer: Float32Array): number | null {
    // Simple autocorrelation
    const SIZE = buffer.length;
    let sumOfSquares = 0;
    for (let i = 0; i < SIZE; i++) {
      sumOfSquares += buffer[i] * buffer[i];
    }
    const rms = Math.sqrt(sumOfSquares / SIZE);
    if (rms < 0.01) return null;

    let r1 = 0, r2 = SIZE - 1;
    const thres = 0.2;
    for (let i = 0; i < SIZE / 2; i++) {
      if (Math.abs(buffer[i]) < thres) { r1 = i; break; }
    }
    for (let i = 1; i < SIZE / 2; i++) {
        if (Math.abs(buffer[SIZE - i]) < thres) { r2 = SIZE - i; break; }
    }

    const subBuffer = buffer.slice(r1, r2);
    const ln = subBuffer.length;
    const c = new Array(ln).fill(0);
    for (let i = 0; i < ln; i++) {
      for (let j = 0; j < ln - i; j++) {
        c[i] = c[i] + subBuffer[j] * subBuffer[j + i];
      }
    }

    let d = 0;
    while (c[d] > c[d + 1]) d++;
    let maxval = -1, maxpos = -1;
    for (let i = d; i < ln; i++) {
      if (c[i] > maxval) {
        maxval = c[i];
        maxpos = i;
      }
    }
    const T0 = maxpos;
    const freq = Tone.getContext().sampleRate / T0;
    
    // Convert freq to MIDI note
    if (freq > 20 && freq < 2000) {
      return 12 * Math.log2(freq / 440) + 69;
    }
    return null;
  }
}

export const audioEngine = new AudioEngine();
