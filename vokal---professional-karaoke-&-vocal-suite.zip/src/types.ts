export interface LyricLine {
  time: number;
  text: string;
  duration?: number;
  pitch?: number;
}

export interface SongPart {
  name: string;
  startTime: number;
  endTime: number;
}

export interface Song {
  id: string;
  title: string;
  artist: string;
  genre: string;
  audioUrl: string;
  videoUrl?: string;
  lyrics: LyricLine[];
  duration: number;
  key: string;
  bpm: number;
  parts?: SongPart[];
}

export interface Recording {
  id: string;
  userId: string;
  songId: string;
  recordingUrl: string;
  score: number;
  pitchData: number[];
  createdAt: string;
  isPublic: boolean;
  customSettings: {
    pitch: number;
    tempo: number;
    vocalEffects: string[];
  };
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL: string;
  bio?: string;
  stats: {
    recordingsCount: number;
    totalScore: number;
  };
}
