/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI } from "@google/genai";
import { Song } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export async function getMedleyRecommendations(currentSong: Song): Promise<string[]> {
  const prompt = `Given the karaoke song "${currentSong.title}" by ${currentSong.artist} (Key: ${currentSong.key}, BPM: ${currentSong.bpm}, Genre: ${currentSong.genre}), 
  suggest 5 similar songs that would work well in a seamless karaoke medley. 
  The transitions should be smooth. Return only the song titles and artists as a list.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt
    });
    
    const text = response.text || "";
    return text.split('\n').filter(line => line.trim().length > 0);
  } catch (error) {
    console.error("Gemini recommendation error:", error);
    return [];
  }
}
