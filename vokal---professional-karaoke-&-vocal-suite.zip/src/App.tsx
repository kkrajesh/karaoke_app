import React, { useState } from "react";
import Navbar from "./components/Navbar";
import KaraokePlayer from "./components/KaraokePlayer";
import SongLibrary from "./components/SongLibrary";
import { Song } from "./types";
import { useAuthState } from "react-firebase-hooks/auth";
import { auth } from "./lib/firebase";
import { Mic2, Trophy, Users, Star, Settings } from "lucide-react";
import { motion } from "motion/react";

export default function App() {
  const [currentView, setCurrentView] = useState("home");
  const [selectedSong, setSelectedSong] = useState<Song | null>(null);
  const [user] = useAuthState(auth);

  const handleSongSelect = (song: Song) => {
    setSelectedSong(song);
    setCurrentView("player");
  };

  return (
    <div className="flex h-screen bg-brand-bg text-brand-text selection:bg-brand-accent selection:text-white font-sans antialiased overflow-hidden">
      <Navbar onNavigate={setCurrentView} currentView={currentView} />
      
      <main className="flex-1 ml-72 flex flex-col overflow-y-auto">
        <div className="p-8 max-w-6xl mx-auto w-full">
          {currentView === "home" && (
            <div className="flex flex-col gap-12 py-12">
              {/* Hero Section */}
              <div className="flex flex-col items-start text-left gap-6">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="px-3 py-1 bg-brand-accent/10 border border-brand-accent/20 text-brand-accent rounded-md text-[10px] font-black uppercase tracking-widest"
                >
                  Premium Vocal Suite v2.0
                </motion.div>
                <h1 className="text-6xl md:text-8xl font-black tracking-tighter leading-[0.85] italic uppercase text-white">
                  Your Voice <br />
                  <span className="text-brand-accent">Unleashed.</span>
                </h1>
                <p className="text-xl text-brand-muted max-w-xl font-serif italic">
                  Professional-grade vocal processing, real-time pitch feedback, and global performance sharing.
                </p>
                <div className="flex gap-4 mt-4">
                  <button 
                    onClick={() => setCurrentView("library")}
                    className="px-8 py-3.5 bg-brand-accent hover:bg-brand-accent/90 text-white font-bold rounded-lg transition-all flex items-center gap-2 shadow-xl shadow-brand-accent/30 uppercase text-xs tracking-widest"
                  >
                    <Mic2 className="w-4 h-4" /> Start Studio Session
                  </button>
                  <button className="px-8 py-3.5 bg-brand-surface hover:bg-brand-surface/80 text-brand-text font-bold rounded-lg transition-all border border-brand-border uppercase text-xs tracking-widest">
                    Community
                  </button>
                </div>
              </div>

              {/* Feature Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FeatureCard 
                  icon={<Trophy className="text-brand-accent" />} 
                  title="Precision Tracking" 
                  desc="Engineered algorithms provide millisecond-accurate pitch and timing benchmarks."
                />
                <FeatureCard 
                  icon={<Settings className="text-brand-accent" />} 
                  title="Studio Processing" 
                  desc="Dynamic pitch shifting, tempo stretching, and studio-grade vocal effects."
                />
                <FeatureCard 
                  icon={<Users className="text-brand-accent" />} 
                  title="Global Stage" 
                  desc="Upload performances and connect with a community of master vocalists."
                />
              </div>
            </div>
          )}

          {currentView === "library" && <SongLibrary onSelect={handleSongSelect} />}
          
          {currentView === "player" && selectedSong && (
            <KaraokePlayer song={selectedSong} />
          )}

          {currentView === "profile" && (
            <div className="flex flex-col items-center justify-center h-full gap-8 py-20 text-center">
               <Star className="w-16 h-16 text-brand-accent animate-pulse" />
               <h2 className="text-4xl font-black text-white italic uppercase tracking-tighter">Activity Hub</h2>
               <p className="text-brand-dim max-w-sm font-serif italic">Your performance metrics and history are being analyzed for optimal feedback. Check back soon.</p>
               <button onClick={() => setCurrentView("home")} className="text-brand-accent font-bold hover:underline underline-offset-8 uppercase tracking-widest text-xs">Return Home</button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

function FeatureCard({ icon, title, desc }: { icon: React.ReactNode, title: string, desc: string }) {
  return (
    <div className="bg-brand-surface p-6 rounded-xl border border-brand-border flex flex-col gap-4 relative overflow-hidden group transition-all hover:border-brand-accent/30">
      <div className="w-10 h-10 bg-brand-accent/5 rounded-lg flex items-center justify-center border border-brand-accent/10">
        {icon}
      </div>
      <h3 className="text-sm font-black uppercase tracking-widest text-white">{title}</h3>
      <p className="text-xs text-brand-dim leading-relaxed font-serif italic">{desc}</p>
      <div className="absolute -right-4 -bottom-4 opacity-[0.03] group-hover:opacity-[0.08] transition-opacity">
        {icon}
      </div>
    </div>
  );
}
