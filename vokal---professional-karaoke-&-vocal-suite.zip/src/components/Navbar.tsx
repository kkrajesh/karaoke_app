import { Search, History, Heart, User, Trophy, Mic2, Layout, Users, Library, Home } from "lucide-react";
import { auth, googleProvider } from "../lib/firebase";
import { signInWithPopup, signOut } from "firebase/auth";
import { useAuthState } from "react-firebase-hooks/auth";
import { motion } from "motion/react";
import { cn } from "../lib/utils";

export default function Navbar({ onNavigate, currentView }: { onNavigate: (view: string) => void, currentView: string }) {
  const [user] = useAuthState(auth);

  const login = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error(error);
    }
  };

  const NavItem = ({ icon: Icon, label, view }: { icon: any, label: string, view: string }) => (
    <button 
      onClick={() => onNavigate(view)}
      className={cn(
        "flex items-center gap-3 w-full p-3 rounded-lg text-sm font-medium transition-all group",
        currentView === view 
          ? "bg-brand-accent/10 text-brand-accent border border-brand-accent/30" 
          : "text-brand-muted hover:bg-brand-surface border border-transparent"
      )}
    >
      <Icon className={cn("w-4 h-4", currentView === view ? "text-brand-accent" : "text-brand-dim group-hover:text-brand-text")} />
      {label}
    </button>
  );

  return (
    <aside className="fixed left-0 top-0 bottom-0 w-72 bg-brand-surface border-r border-brand-border flex flex-col z-50">
      <div className="p-6 border-b border-brand-border">
        <div 
          className="flex items-center gap-3 mb-6 cursor-pointer"
          onClick={() => onNavigate("home")}
        >
          <div className="w-8 h-8 bg-brand-accent rounded flex items-center justify-center font-bold text-white shadow-[0_0_15px_rgba(79,70,229,0.4)]">
            <Mic2 className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-xl font-bold tracking-tight text-white italic">Vokal<span className="text-brand-accent font-black">Pro</span></h1>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-dim" />
          <input 
            type="text" 
            placeholder="Search tracks..." 
            className="w-full bg-brand-bg border border-brand-border rounded-lg py-2 pl-9 pr-4 text-sm focus:outline-none focus:border-brand-accent transition-all placeholder:text-brand-dim"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-2">
        <p className="text-[10px] uppercase tracking-widest text-brand-dim font-black mb-1 ml-2">Main Menu</p>
        <NavItem icon={Home} label="Home" view="home" />
        <NavItem icon={Library} label="Library" view="library" />
        <NavItem icon={Users} label="Community" view="community" />
        
        {user && (
          <>
            <div className="my-4 h-px bg-brand-border mx-2" />
            <p className="text-[10px] uppercase tracking-widest text-brand-dim font-black mb-1 ml-2">Personal</p>
            <NavItem icon={History} label="My Activity" view="profile" />
          </>
        )}
      </div>

      <div className="p-4 bg-brand-bg border-t border-brand-border">
        {user ? (
          <div className="flex items-center gap-3">
            <div className="relative group">
              <img src={user.photoURL || ""} alt="Profile" className="w-10 h-10 rounded-lg border border-brand-border object-cover" />
              <div className="absolute inset-0 bg-brand-accent/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-bold text-white truncate">{user.displayName}</p>
              <button 
                onClick={() => signOut(auth)}
                className="text-[10px] text-brand-dim hover:text-brand-accent font-bold uppercase tracking-wider"
              >
                Sign Out
              </button>
            </div>
          </div>
        ) : (
          <button 
            onClick={login}
            className="w-full py-2.5 bg-brand-accent hover:bg-brand-accent/90 text-white text-xs font-bold rounded-lg transition-all shadow-lg shadow-brand-accent/20 uppercase tracking-widest"
          >
            Start Singing
          </button>
        )}
      </div>
    </aside>
  );
}
