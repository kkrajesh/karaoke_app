import * as Tone from 'tone';
import { useState, useRef, useEffect } from "react";
import ReactPlayer from "react-player";
import { Song, LyricLine } from "../types";
import { Play, Pause, RotateCcw, Sliders, Mic, Music, Layout, Activity, ChevronRight, Wand2, Info, SkipBack, SkipForward, RotateCw } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { formatTime, cn } from "../lib/utils";
import { audioEngine } from "../lib/audioEngine";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from "recharts";
import { getMedleyRecommendations } from "../services/geminiService";

const ReactPlayerComp = ReactPlayer as any;

export default function KaraokePlayer({ song }: { song: Song }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [pitch, setPitch] = useState(0);
  const [tempo, setTempo] = useState(1);
  const [showLyrics, setShowLyrics] = useState(!song.videoUrl);
  const [showAnalyzer, setShowAnalyzer] = useState(true);
  const [duration, setDuration] = useState(song.duration);
  const [currentLyrics, setCurrentLyrics] = useState<LyricLine[]>([]);
  const [micActive, setMicActive] = useState(false);
  const [vocalData, setVocalData] = useState<{ time: number; pitch: number; target: number }[]>([]);
  const [recommendations, setRecommendations] = useState<string[]>([]);
  const [isLoadingRecs, setIsLoadingRecs] = useState(false);
  const isYouTube = useMemo(() => 
    (song.audioUrl && (song.audioUrl.includes("youtube.com") || song.audioUrl.includes("youtu.be"))) || 
    (song.videoUrl && (song.videoUrl.includes("youtube.com") || song.videoUrl.includes("youtu.be"))),
    [song.audioUrl, song.videoUrl]
  );

  const isVideo = useMemo(() => 
    !!song.videoUrl || (song.audioUrl && !!song.audioUrl.match(/\.(mp4|webm|mov|m4v|ogg|ogv)$/i)),
    [song.audioUrl, song.videoUrl]
  );
  
  const mediaUrl = useMemo(() => {
    const raw = isVideo ? (song.videoUrl || song.audioUrl) : song.audioUrl;
    if (!raw) return "";
    
    // Don't proxy YouTube, local paths (/, blob, data), or relative paths (don't start with http)
    const isLocal = raw.startsWith('/') || 
                    raw.startsWith('blob:') || 
                    raw.startsWith('data:') || 
                    !raw.startsWith('http');
                    
    if (isYouTube || isLocal) {
      console.log("KaraokePlayer: Using raw URL:", raw, "isLocal:", isLocal);
      return raw;
    }
    
    const proxied = `/api/proxy-audio?url=${encodeURIComponent(raw)}`;
    console.log("KaraokePlayer: Use proxied URL for:", raw);
    return proxied;
  }, [isYouTube, isVideo, song.videoUrl, song.audioUrl]);
  
  const playerRef = useRef<any>(null);
  const timerRef = useRef<number | null>(null);

  const fetchRecommendations = async () => {
    setIsLoadingRecs(true);
    const recs = await getMedleyRecommendations(song);
    setRecommendations(recs);
    setIsLoadingRecs(false);
  };

  useEffect(() => {
    if (isVideo && !isYouTube && playerRef.current && isPlayerReady) {
      if (isPlaying) {
        playerRef.current.play().catch((e: any) => {
          if (e.name !== 'AbortError') {
            console.error("Native play failed:", e);
          }
        });
      } else {
        playerRef.current.pause();
      }
    }
  }, [isPlaying, isVideo, isYouTube, isPlayerReady]);

  const jumpToPart = (start: number) => {
    const targetTime = Math.max(0, Math.min(duration, start));
    setCurrentTime(targetTime);
    
    if (playerRef.current) {
      if (typeof playerRef.current.seekTo === 'function') {
        playerRef.current.seekTo(targetTime, "seconds");
      } else if ('currentTime' in playerRef.current) {
        playerRef.current.currentTime = targetTime;
      }
    }
    
    if (!isYouTube && !isVideo) {
      audioEngine.seekTo(targetTime);
    }
    
    updateLyrics(targetTime);
  };

  const seekOffset = (offset: number) => {
    jumpToPart(currentTime + offset);
  };

  const [isLoadingAudio, setIsLoadingAudio] = useState(true);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [isPlayerReady, setIsPlayerReady] = useState(false);

  const safetyTimeoutRef = useRef<number | null>(null);

  useEffect(() => {
    const initAudio = async () => {
      console.log("KaraokePlayer: Initializing audio for song:", song.id, "isYouTube:", isYouTube, "isVideo:", isVideo);
      
      // Reset state for new song
      setDuration(song.duration || 0);
      setCurrentTime(0);
      setIsLoadingAudio(true);
      setAudioError(null);
      setIsPlayerReady(false);
      setShowLyrics(!song.videoUrl);

      // Safety timeout to prevent infinite "Connecting"
      if (safetyTimeoutRef.current) clearTimeout(safetyTimeoutRef.current);
      safetyTimeoutRef.current = window.setTimeout(() => {
        setIsLoadingAudio((currentLoading) => {
          if (currentLoading) {
            console.warn("KaraokePlayer: Initialization safety timeout reached. Forcing ready state.");
            setIsPlayerReady(true);
            return false;
          }
          return currentLoading;
        });
      }, 15000);

      if (isYouTube) {
        console.log("KaraokePlayer: YouTube mode - waiting for ReactPlayer onReady. URL:", mediaUrl);
        return;
      }
      
      if (isVideo) {
        console.log("KaraokePlayer: Video/File mode - waiting for ReactPlayer onReady. URL:", mediaUrl);
        // We still set a timeout to clear loading if onReady never fires
        return;
      } else {
        // Audio only setup
        try {
          const audioToProxy = song.audioUrl;
          const proxyUrl = (audioToProxy.startsWith('http') && !audioToProxy.includes('youtube.com') && !audioToProxy.includes('youtu.be'))
            ? `/api/proxy-audio?url=${encodeURIComponent(audioToProxy)}`
            : audioToProxy;
            
          console.log("KaraokePlayer: Local Audio mode - initializing AudioEngine with URL:", proxyUrl);
          await audioEngine.init(proxyUrl);
          const engineDuration = audioEngine.getDuration();
          console.log("KaraokePlayer: AudioEngine ready, duration:", engineDuration);
          
          if (engineDuration > 0) {
            setDuration(engineDuration);
          } else if (song.duration > 0) {
            setDuration(song.duration);
          }
          
          if (safetyTimeoutRef.current) {
            clearTimeout(safetyTimeoutRef.current);
            safetyTimeoutRef.current = null;
          }
          
          setIsLoadingAudio(false);
          setIsPlayerReady(true);
        } catch (error) {
          console.error("KaraokePlayer: Failed to load song audio via AudioEngine:", error);
          if (safetyTimeoutRef.current) {
            clearTimeout(safetyTimeoutRef.current);
            safetyTimeoutRef.current = null;
          }
          setAudioError("The audio file could not be loaded. Please check the file format or connection.");
          setIsLoadingAudio(false);
          // Still set ready so user can try to play if they want
          setIsPlayerReady(true);
        }
      }
    };
    initAudio();
    return () => {
      audioEngine.stop();
      if (safetyTimeoutRef.current) clearTimeout(safetyTimeoutRef.current);
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [song.id, isYouTube, isVideo, song.audioUrl, song.duration]);

  // Audio-only progress loop
  useEffect(() => {
    let animationFrame: number;
    const loop = () => {
      if (isPlaying && !isYouTube && !isVideo) {
        const time = audioEngine.getCurrentTime();
        if (!isNaN(time) && time >= 0) {
          setCurrentTime(time);
          updateLyrics(time);
        }
        animationFrame = requestAnimationFrame(loop);
      }
    };

    if (isPlaying && !isYouTube && !isVideo) {
      console.log("KaraokePlayer: Starting audio progress loop (RAF). AudioEngine state:", Tone.getContext().state);
      animationFrame = requestAnimationFrame(loop);
    } else {
      console.log("KaraokePlayer: Stopping audio progress loop");
    }

    return () => {
      if (animationFrame) cancelAnimationFrame(animationFrame);
    };
  }, [isPlaying, isYouTube, isVideo]);

  const toggleMic = async () => {
    try {
      if (Tone.getContext().state !== 'running') {
        await Tone.start();
        console.log("KaraokePlayer: Tone.js context started (mic)");
      }
      if (micActive) {
        const blob = await audioEngine.stopRecording();
        setMicActive(false);
        console.log("KaraokePlayer: Recording stopped, blob size:", blob?.size);
      } else {
        await audioEngine.startRecording();
        setMicActive(true);
        setVocalData([]); 
      }
    } catch (error) {
      console.error("KaraokePlayer: Microphone access or recording error:", error);
      alert("Unable to access microphone. Please ensure you have granted permission.");
      setMicActive(false);
    }
  };

  useEffect(() => {
    let animationFrame: number;
    const updatePitch = () => {
      if (micActive) {
        const detectedPitch = audioEngine.getPitch();
        const activeLyricIndex = song.lyrics.findIndex((l) => l.time > currentTime) - 1;
        const targetPitch = song.lyrics[activeLyricIndex]?.pitch || 60; // Default C4

        if (detectedPitch) {
          setVocalData(prev => [...prev.slice(-100), {
            time: currentTime,
            pitch: detectedPitch,
            target: targetPitch
          }]);
        }
      }
      if (showAnalyzer) {
        animationFrame = requestAnimationFrame(updatePitch);
      }
    };
    
    if (showAnalyzer) {
      animationFrame = requestAnimationFrame(updatePitch);
    }

    return () => cancelAnimationFrame(animationFrame);
  }, [micActive, showAnalyzer, currentTime, song.lyrics]);

  const togglePlay = async () => {
    try {
      console.log("KaraokePlayer: togglePlay called. current isPlaying:", isPlaying);
      if (Tone.getContext().state !== 'running') {
        await Tone.start();
        console.log("KaraokePlayer: Tone.js context started (play)");
      }
      
      if (isPlaying) {
        if (!isYouTube && !isVideo) {
          audioEngine.stop();
          audioEngine.seekTo(currentTime);
        }
      } else {
        if (!isYouTube && !isVideo) {
          audioEngine.play();
        }
      }
      setIsPlaying(!isPlaying);
    } catch (error) {
      console.error("KaraokePlayer: Playback toggle error:", error);
    }
  };

  useEffect(() => {
    // We rely on ReactPlayer's onProgress or Native Video's onTimeUpdate for timing
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const updateLyrics = (time: number) => {
    const nextLyricIndex = song.lyrics.findIndex((l) => l.time > time);
    const activeIndex = nextLyricIndex === -1 ? song.lyrics.length - 1 : nextLyricIndex - 1;
    const start = Math.max(0, activeIndex - 1);
    const end = Math.min(song.lyrics.length, activeIndex + 3);
    setCurrentLyrics(song.lyrics.slice(start, end));
  };

  const handlePitchChange = (p: number) => {
    setPitch(p);
    if (!isYouTube && !isVideo) audioEngine.setPitch(p);
  };

  const handleTempoChange = (t: number) => {
    setTempo(t);
    if (!isYouTube) {
      if (isVideo && playerRef.current) {
        playerRef.current.playbackRate = t;
      } else if (!isVideo) {
        audioEngine.setTempo(t);
      }
    }
  };

  return (
    <div id="karaoke-player-container" className="flex flex-col gap-6 w-full max-w-5xl mx-auto py-8 px-4 md:px-0 animate-in fade-in slide-in-from-bottom-4 duration-1000 border-x border-brand-border/20 shadow-[0_0_100px_rgba(79,70,229,0.05)]">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[300px] bg-brand-accent/5 blur-[120px] -z-10 rounded-full pointer-events-none"></div>
      <header className="flex items-center justify-between bg-brand-surface/80 backdrop-blur-xl border border-brand-border p-4 rounded-xl shadow-[0_8px_32px_rgba(0,0,0,0.3)]">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className={cn("w-2 h-2 rounded-full", micActive ? "bg-red-500 animate-pulse" : "bg-brand-dim")}></div>
            <span className={cn("text-xs font-mono tracking-widest uppercase", micActive ? "text-red-500" : "text-brand-dim")}>
              {micActive ? `REC ${formatTime(currentTime)}` : "STANDBY"}
            </span>
          </div>
          <div className="h-4 w-px bg-brand-border"></div>
          <div className="flex gap-2">
            <button className="text-[10px] font-black text-white bg-brand-accent px-3 py-1 rounded-md uppercase tracking-wider">Master Track</button>
            <button className="text-[10px] font-black text-brand-muted bg-brand-bg px-3 py-1 rounded-md border border-brand-border uppercase tracking-wider">A/B Comparison</button>
          </div>
        </div>
        <div className="flex items-center gap-6 text-[10px] font-black text-brand-muted uppercase tracking-[0.2em]">
          <span>Accuracy: <span className="text-emerald-400">94%</span></span>
          <span>Pitch: <span className="text-emerald-400">+12c</span></span>
        </div>
      </header>
      {/* Video / Visualizer Stage */}
      <div className="relative aspect-video bg-brand-bg rounded-xl overflow-hidden border-2 border-brand-border shadow-[0_32px_64px_-16px_rgba(0,0,0,0.6)] group">
        {(isLoadingAudio || audioError) && (
          <div className="absolute inset-0 z-50 bg-brand-bg/95 flex flex-col items-center justify-center p-8 text-center">
            {isLoadingAudio ? (
              <div className="flex flex-col items-center gap-6">
                <div className="relative">
                  <div className="w-20 h-20 border-2 border-brand-accent/20 rounded-full"></div>
                  <div className="absolute inset-0 w-20 h-20 border-2 border-brand-accent border-t-transparent rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Music className="w-6 h-6 text-brand-accent animate-pulse" />
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <p className="text-sm font-black uppercase tracking-[0.5em] text-white">Connecting To Studio</p>
                  <p className="text-[10px] text-brand-dim uppercase font-bold tracking-widest animate-pulse">Establishing high-fidelity stream...</p>
                </div>
                {isYouTube && (
                  <button 
                    onClick={() => { setIsLoadingAudio(false); setIsPlayerReady(true); }}
                    className="mt-4 text-[9px] font-black uppercase tracking-widest text-brand-dim hover:text-brand-accent transition-all underline decoration-brand-accent/30 underline-offset-4"
                  >
                    Bypass & Forced Start
                  </button>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center gap-4 max-w-sm">
                <div className="w-12 h-12 flex items-center justify-center bg-red-500/10 text-red-500 rounded-full">
                  <Activity className="w-6 h-6" />
                </div>
                <p className="text-xs font-black uppercase tracking-[0.2em] text-red-500">Signal Interrupted</p>
                <p className="text-sm text-brand-muted font-serif italic">{audioError}</p>
                <button 
                  onClick={() => window.location.reload()}
                  className="mt-4 px-6 py-2 bg-brand-accent text-white rounded-md text-[10px] font-black uppercase tracking-widest hover:bg-brand-accent/90 transition-all"
                >
                  Retry Connection
                </button>
              </div>
            )}
          </div>
        )}
        
          <div className="w-full h-full relative bg-black shadow-inner">
            {isYouTube ? (
              <ReactPlayerComp
                key={song.id}
                ref={playerRef}
                url={mediaUrl}
                playing={isPlaying}
                playbackRate={tempo}
                progressInterval={100}
                width="100%"
                height="100%"
                controls={false}
                muted={false}
                volume={1}
                onReady={() => {
                  console.log("KaraokePlayer: YouTube Player Ready");
                  if (safetyTimeoutRef.current) {
                    clearTimeout(safetyTimeoutRef.current);
                    safetyTimeoutRef.current = null;
                  }
                  setIsLoadingAudio(false);
                  setIsPlayerReady(true);
                  const d = playerRef.current?.getDuration?.();
                  if (d && d > 0) setDuration(d);
                }}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onProgress={(state: any) => {
                  if (isPlaying) {
                    setCurrentTime(state.playedSeconds);
                    updateLyrics(state.playedSeconds);
                  }
                }}
                onError={(e: any) => {
                  console.error("KaraokePlayer: YouTube Error:", e);
                  setIsLoadingAudio(false);
                  setAudioError(`YouTube failed to load: ${JSON.stringify(e)}`);
                }}
                config={{
                  youtube: {
                    playerVars: { 
                      rel: 0, 
                      modestbranding: 1, 
                      enablejsapi: 1,
                      autoplay: 1,
                      showinfo: 0,
                      controls: 0
                    }
                  }
                }}
                style={{ opacity: 1, transition: 'opacity 0.5s ease-in-out' }}
              />
            ) : isVideo ? (
              /* Native Video tag for Files/Proxied Video */
              <video
                key={song.id}
                ref={playerRef}
                src={mediaUrl}
                className="w-full h-full object-contain bg-black"
                playsInline
                preload="auto"
                crossOrigin="anonymous"
                onCanPlay={() => {
                  console.log("KaraokePlayer: Native Video Ready");
                  if (safetyTimeoutRef.current) {
                    clearTimeout(safetyTimeoutRef.current);
                    safetyTimeoutRef.current = null;
                  }
                  setIsLoadingAudio(false);
                  setIsPlayerReady(true);
                  const d = playerRef.current?.duration;
                  if (d && d > 0) setDuration(d);
                }}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onTimeUpdate={() => {
                  if (isPlaying && playerRef.current) {
                    const time = playerRef.current.currentTime;
                    setCurrentTime(time);
                    updateLyrics(time);
                  }
                }}
                onEnded={() => setIsPlaying(false)}
                onError={(e: any) => {
                  const error = playerRef.current?.error;
                  console.error("KaraokePlayer: Native Video error:", error);
                  setIsLoadingAudio(false);
                  setAudioError(`Video failed to load: ${error?.message || "Unknown error"}. URL: ${mediaUrl}`);
                }}
              />
            ) : (
            /* Background image if no video and no YouTube */
            <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-brand-accent/20 to-brand-bg select-none">
              <div className="relative group">
                <Music className="w-32 h-32 text-brand-accent/20 animate-pulse group-hover:scale-110 transition-transform" />
                <div className="absolute inset-0 bg-brand-accent/5 blur-3xl rounded-full"></div>
              </div>
              <div className="absolute top-12 left-12 opacity-10 uppercase font-black text-6xl tracking-tighter italic">Karaoke Studio</div>
            </div>
          )}
        </div>

        {/* Lyrics Overlay - Matched to User Image */}
        {showLyrics && (
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none p-12 z-20">
            <div className="flex flex-col items-center gap-2 max-w-4xl w-full">
              {/* Visual countdown lead-in >>>>>> */}
              <div className="h-12 flex items-center justify-center mb-2">
                {(() => {
                  const nextLyric = song.lyrics.find(l => l.time > currentTime);
                  if (!nextLyric) return null;
                  const timeToNext = nextLyric.time - currentTime;
                  if (timeToNext > 0 && timeToNext < 3) {
                    const arrows = Math.ceil((3 - timeToNext) * 2);
                    return (
                      <div className="text-3xl md:text-5xl font-black text-cyan-400 drop-shadow-[0_4px_8px_rgba(0,0,0,1)] tracking-tighter animate-pulse">
                        {">".repeat(Math.min(6, arrows))}
                      </div>
                    );
                  }
                  return null;
                })()}
              </div>

              <AnimatePresence mode="popLayout">
                {(() => {
                  const activeIndex = song.lyrics.findIndex((l) => l.time > currentTime) - 1;
                  const displayIndex = activeIndex < 0 ? 0 : activeIndex;
                  const linesToShow = song.lyrics.slice(displayIndex, displayIndex + 4);
                  
                  return linesToShow.map((lyric, idx) => {
                    const isCurrent = (lyric.time <= currentTime) && (idx === 0 || (song.lyrics[displayIndex + idx + 1]?.time > currentTime || !song.lyrics[displayIndex + idx + 1]));
                    
                    return (
                      <motion.p
                        key={`${lyric.time}-${lyric.text}`}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ 
                          opacity: 1, 
                          scale: 1,
                          color: isCurrent ? "#ffffff" : "rgba(255,255,255,0.4)",
                        }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        transition={{ duration: 0.3 }}
                        className={cn(
                          "text-3xl md:text-6xl font-sans font-black text-center leading-tight mb-2 tracking-tight transition-all duration-300",
                          isCurrent 
                            ? "drop-shadow-[0_0_20px_rgba(34,211,238,0.8)] [text-shadow:4px_4px_0px_#000,-4px_-4px_0px_#000,4px_-4px_0px_#000,-4px_4px_0px_#000,0px_0px_15px_rgba(0,0,0,1)]" 
                            : "drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] [text-shadow:2px_2px_0px_#000,-2px_-2px_0px_#000,2px_-2px_0px_#000,-2px_2px_0px_#000]"
                        )}
                        style={{
                          WebkitTextStroke: isCurrent ? '2px #22d3ee' : 'none'
                        }}
                      >
                        {lyric.text}
                      </motion.p>
                    );
                  });
                })()}
              </AnimatePresence>
            </div>
          </div>
        )}

        {/* Vocal Accuracy Graph Overlay */}
        {showAnalyzer && (
          <div className="absolute bottom-4 left-4 right-4 h-24 bg-brand-bg/60 backdrop-blur-md rounded-lg border border-brand-border overflow-hidden">
             <div className="absolute top-2 left-2 flex items-center gap-1 text-[8px] uppercase font-black text-brand-dim tracking-widest">
                <Activity className="w-2.5 h-2.5" /> Vocal Precision Analysis
             </div>
             <ResponsiveContainer width="100%" height="100%">
               <LineChart data={vocalData}>
                 <Line type="monotone" dataKey="target" stroke="#4F46E5" strokeWidth={1.5} dot={false} strokeOpacity={0.4} strokeDasharray="4 4" />
                 <Line type="monotone" dataKey="pitch" stroke="#10B981" strokeWidth={2} dot={false} />
               </LineChart>
             </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="grid grid-cols-12 gap-6 items-stretch">
        
        {/* Playback & Song Info */}
        <div className="col-span-12 lg:col-span-4 bg-brand-surface p-5 rounded-xl border border-brand-border flex flex-col justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-1.5">
                <button 
                  onClick={() => seekOffset(-30)} 
                  title="Backward 30s"
                  className="p-1 text-brand-dim hover:text-brand-accent transition-colors"
                >
                  <SkipBack className="w-3.5 h-3.5" />
                </button>
                <button 
                  onClick={() => seekOffset(-10)} 
                  title="Backward 10s"
                  className="p-1 text-brand-dim hover:text-brand-accent transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button 
                  onClick={togglePlay}
                  disabled={isLoadingAudio || !!audioError || (isYouTube && !isPlayerReady)}
                  className="w-12 h-12 flex items-center justify-center bg-brand-accent text-white rounded-full hover:scale-105 transition-all shadow-[0_0_20px_rgba(79,70,229,0.3)] disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isPlaying ? <Pause className="fill-current w-5 h-5" /> : <Play className="fill-current w-5 h-5 ml-1" />}
                </button>
                <button 
                  onClick={() => seekOffset(10)} 
                  title="Forward 10s"
                  className="p-1 text-brand-dim hover:text-brand-accent transition-colors"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>
                <button 
                  onClick={() => seekOffset(30)} 
                  title="Forward 30s"
                  className="p-1 text-brand-dim hover:text-brand-accent transition-colors"
                >
                  <SkipForward className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <div className="flex flex-col overflow-hidden">
              <span className="text-sm font-black uppercase tracking-tight text-white truncate">{song.title}</span>
              <span className="text-[10px] text-brand-dim uppercase font-bold truncate tracking-widest">{song.artist}</span>
            </div>
          </div>
          
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2 text-[10px] font-mono font-bold text-brand-dim uppercase tracking-widest">
              <span>{formatTime(currentTime)}</span>
              <div className="flex-1 relative flex items-center group">
                <input 
                  type="range"
                  min="0"
                  max={duration || 100}
                  step="0.1"
                  value={currentTime}
                  onChange={(e) => jumpToPart(parseFloat(e.target.value))}
                  className="w-full absolute inset-0 opacity-0 cursor-pointer z-10"
                />
                <div className="flex-1 h-1 bg-brand-bg rounded-full overflow-hidden border border-brand-border group-hover:border-brand-accent/30 transition-colors">
                  <div 
                    className="h-full bg-brand-accent shadow-[0_0_8px_rgba(79,70,229,0.5)] transition-all duration-100" 
                    style={{ width: `${(currentTime / (duration || 1)) * 100}%` }}
                  />
                </div>
              </div>
              <span>{formatTime(duration)}</span>
            </div>
          </div>
        </div>

        {/* Audio Engine Parameters */}
        <div className="col-span-12 lg:col-span-5 bg-brand-surface p-5 rounded-xl border border-brand-border grid grid-cols-2 gap-6 relative">
           {isYouTube && (
             <div className="absolute inset-0 z-10 bg-brand-bg/60 backdrop-blur-[1px] flex items-center justify-center rounded-xl p-4">
                <div className="flex items-center gap-2 text-[8px] font-black text-brand-accent uppercase tracking-widest bg-brand-surface px-3 py-1.5 rounded border border-brand-accent/30 shadow-xl">
                  <Info className="w-2.5 h-2.5" /> Pitch Shift Disabled for YouTube
                </div>
             </div>
           )}
           <div className="flex flex-col gap-4 italic font-serif">
              <span className="text-[9px] font-black uppercase text-brand-dim tracking-[0.3em] font-sans not-italic">Pitch Balance</span>
              <div className="flex items-center justify-between bg-brand-bg p-2 rounded-lg border border-brand-border font-sans not-italic">
                <button onClick={() => handlePitchChange(pitch - 0.5)} className="w-6 h-6 flex items-center justify-center hover:bg-brand-surface rounded text-brand-dim">-</button>
                <span className="text-xs font-mono font-bold text-brand-accent">{pitch > 0 ? `+${pitch.toFixed(1)}` : pitch.toFixed(1)}</span>
                <button onClick={() => handlePitchChange(pitch + 0.5)} className="w-6 h-6 flex items-center justify-center hover:bg-brand-surface rounded text-brand-dim">+</button>
              </div>
              <input 
                type="range" min="-6" max="6" step="0.5" 
                value={pitch} onChange={(e) => handlePitchChange(parseFloat(e.target.value))}
                className="w-full accent-brand-accent h-1"
              />
           </div>

           <div className="flex flex-col gap-4 italic font-serif">
              <span className="text-[9px] font-black uppercase text-brand-dim tracking-[0.3em] font-sans not-italic">Tempo Calibration</span>
              <div className="flex items-center justify-between bg-brand-bg p-2 rounded-lg border border-brand-border font-sans not-italic">
                <button onClick={() => handleTempoChange(tempo - 0.1)} className="w-6 h-6 flex items-center justify-center hover:bg-brand-surface rounded text-brand-dim">-</button>
                <span className="text-xs font-mono font-bold text-brand-accent">{(tempo * 100).toFixed(0)}%</span>
                <button onClick={() => handleTempoChange(tempo + 0.1)} className="w-6 h-6 flex items-center justify-center hover:bg-brand-surface rounded text-brand-dim">+</button>
              </div>
              <input 
                type="range" min="0.5" max="2" step="0.1" 
                value={tempo} onChange={(e) => handleTempoChange(parseFloat(e.target.value))}
                className="w-full accent-brand-accent h-1"
              />
           </div>
        </div>

        {/* Global Controls */}
        <div className="col-span-12 lg:col-span-3 bg-brand-surface p-5 rounded-xl border border-brand-border flex flex-col justify-between">
           <button 
             onClick={toggleMic}
             className={cn(
               "w-full py-3 rounded-lg text-[10px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-2 transition-all border",
               micActive 
                ? "bg-red-500/10 text-red-500 border-red-500 animate-pulse shadow-[0_0_15px_rgba(239,68,68,0.2)]" 
                : "bg-brand-bg text-brand-muted border-brand-border hover:border-brand-accent hover:text-brand-accent"
             )}
           >
             <Mic className="w-3.5 h-3.5" />
             {micActive ? "Processing Input..." : "Activate Mic"}
           </button>

           <div className="flex gap-2">
              <button 
                onClick={() => setShowLyrics(!showLyrics)} 
                className={cn(
                  "flex-1 py-2 rounded border text-[10px] font-bold uppercase transition-all", 
                  showLyrics ? "bg-brand-accent/10 border-brand-accent/30 text-brand-accent" : "bg-brand-bg border-brand-border text-brand-dim"
                )}
              >
                Lyrics
              </button>
              <button onClick={() => setShowAnalyzer(!showAnalyzer)} className={cn("flex-1 py-2 rounded border text-[10px] font-bold uppercase transition-all", showAnalyzer ? "bg-brand-accent/10 border-brand-accent/30 text-brand-accent" : "bg-brand-bg border-brand-border text-brand-dim")}>Vizualizer</button>
           </div>
        </div>
      </div>

      {/* Sections & AI Recommendations */}
      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-12 md:col-span-5 bg-brand-surface p-6 rounded-xl border border-brand-border flex flex-col gap-4">
           <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-brand-dim flex items-center gap-2 border-b border-brand-border pb-3">
             <Layout className="w-3 h-3 text-brand-accent" /> Arrangement Markers
           </h4>
           <div className="flex flex-wrap gap-2">
              {["Verse 1", "Chorus", "Verse 2", "Bridge", "Final Chorus"].map((part, i) => (
                <button 
                  key={part}
                  onClick={() => jumpToPart(i * (duration / 5))}
                  className="px-3 py-2 bg-brand-bg hover:bg-brand-accent hover:text-white border border-brand-border rounded-md text-[10px] font-bold uppercase tracking-widest transition-all"
                >
                  {part}
                </button>
              ))}
           </div>
        </div>

        <div className="col-span-12 md:col-span-7 bg-brand-surface p-6 rounded-xl border border-brand-border flex flex-col gap-4">
           <div className="flex items-center justify-between border-b border-brand-border pb-3">
             <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-brand-dim flex items-center gap-2">
               <Wand2 className="w-3 h-3 text-brand-accent" /> AI Medley Calibration
             </h4>
             <button 
               onClick={fetchRecommendations}
               disabled={isLoadingRecs}
               className="text-[10px] font-black text-brand-accent hover:underline disabled:opacity-50 uppercase tracking-widest"
             >
               {isLoadingRecs ? "Computing..." : "Generate Medley"}
             </button>
           </div>
           
           <div className="grid grid-cols-2 gap-3">
              {recommendations.length > 0 ? (
                recommendations.map((rec, i) => (
                  <div key={i} className="flex items-center justify-between group cursor-pointer text-[10px] p-2.5 bg-brand-bg hover:bg-brand-accent/5 border border-brand-border hover:border-brand-accent/30 rounded-lg transition-all font-bold uppercase tracking-wider text-brand-muted">
                    <span className="truncate group-hover:text-white">{rec}</span>
                    <ChevronRight className="w-3 h-3 text-brand-dim group-hover:text-brand-accent shrink-0" />
                  </div>
                ))
              ) : (
                <div className="col-span-2 flex items-center justify-center p-4 border border-dashed border-brand-border rounded-lg">
                  <p className="text-[10px] text-brand-dim font-serif italic">Initialize AI suggestions based on current key and tempo...</p>
                </div>
              )}
           </div>
        </div>
      </div>
    </div>
  );
}
