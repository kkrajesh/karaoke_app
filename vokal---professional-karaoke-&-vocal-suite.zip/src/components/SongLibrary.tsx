import { useState } from "react";
import { Song } from "../types";
import { Search, Music, Play, Plus, ChevronRight, Mic2, Upload } from "lucide-react";
import { motion } from "motion/react";

const MOCK_SONGS: Song[] = [
  {
    id: "1",
    title: "Bohemian Rhapsody",
    artist: "Queen",
    genre: "Rock",
    duration: 354,
    audioUrl: `/api/proxy-audio?url=${encodeURIComponent("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3")}`,
    key: "Bb",
    bpm: 72,
    lyrics: [
      { time: 0, text: "Is this the real life?" },
      { time: 3, text: "Is this just fantasy?" },
      { time: 6, text: "Caught in a landslide" },
      { time: 9, text: "No escape from reality" },
    ]
  },
  {
    id: "2",
    title: "Levitating",
    artist: "Dua Lipa",
    genre: "Pop",
    duration: 203,
    audioUrl: `/api/proxy-audio?url=${encodeURIComponent("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3")}`,
    key: "Bm",
    bpm: 103,
    lyrics: [
      { time: 0, text: "If you want to run away with me" },
      { time: 3, text: "I know a galaxy" },
    ]
  },
  {
    id: "3",
    title: "Shape of You",
    artist: "Ed Sheeran",
    genre: "Pop",
    duration: 233,
    audioUrl: `/api/proxy-audio?url=${encodeURIComponent("https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3")}`,
    key: "C#m",
    bpm: 96,
    lyrics: [
      { time: 0, text: "The club isn't the best place to find a lover" },
      { time: 3, text: "So the bar is where I go" },
    ]
  }
];

export default function SongLibrary({ onSelect }: { onSelect: (song: Song) => void }) {
  const [search, setSearch] = useState("");
  const [customUrl, setCustomUrl] = useState("");

  const handleCustomLoad = () => {
    if (!customUrl) return;
    
    // Create a temporary song object for the URL
    const isYouTube = customUrl.includes("youtube.com") || customUrl.includes("youtu.be");
    
    const isVideo = customUrl.match(/\.(mp4|webm|ogg|mov)$/i) || (!isYouTube && customUrl.includes('blob:'));
    
    // Don't proxy blob URLs or YouTube URLs
    const needsProxy = !isYouTube && !customUrl.startsWith('blob:');
    
    const customSong: Song = {
      id: `custom-${Date.now()}`,
      title: isYouTube ? "YouTube Stream" : "Custom Track",
      artist: "External Source",
      genre: "Custom",
      duration: 300, // Placeholder
      audioUrl: needsProxy ? `/api/proxy-audio?url=${encodeURIComponent(customUrl)}` : customUrl,
      videoUrl: isVideo ? customUrl : undefined,
      key: "Unknown",
      bpm: 120,
      lyrics: [{ time: 0, text: "Ready to sing?" }]
    };
    
    onSelect(customSong);
  };

  const filtered = MOCK_SONGS.filter(s => 
    s.title.toLowerCase().includes(search.toLowerCase()) ||
    s.artist.toLowerCase().includes(search.toLowerCase()) ||
    s.genre.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col gap-10 w-full max-w-6xl mx-auto py-10 px-4">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="flex flex-col gap-4">
          <h2 className="text-5xl font-black tracking-tighter italic uppercase text-white shadow-brand-accent/20">Studio <span className="text-brand-accent">Archive</span></h2>
          <p className="text-brand-muted font-serif italic text-sm">Select a master track, load a URL, or drop your own file.</p>
        </div>

        <div className="flex flex-col md:flex-row gap-4 w-full max-w-2xl">
          {/* Local File Upload Container */}
          <div className="flex flex-col gap-2 flex-1">
            <span className="text-[10px] font-black uppercase text-brand-dim tracking-widest ml-1">Studio Upload (Media + LRC)</span>
            <div className="flex gap-2">
              <label className="flex items-center justify-center gap-2 flex-1 bg-brand-surface border border-brand-border border-dashed rounded-lg py-2.5 px-4 text-xs font-bold text-brand-accent hover:border-brand-accent/50 hover:bg-brand-accent/5 cursor-pointer transition-all">
                <Upload className="w-3.5 h-3.5" />
                <span>Media File</span>
                <input 
                  type="file" 
                  accept="audio/*,video/*" 
                  className="hidden" 
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const url = URL.createObjectURL(file);
                      const isVideo = file.type.startsWith('video/') || file.name.match(/\.(mp4|webm|mov|m4v|ogg|ogv)$/i);
                      const localSong: Song = {
                        id: `local-${Date.now()}`,
                        title: file.name.split('.')[0],
                        artist: "Local Upload",
                        genre: "Custom",
                        duration: 0,
                        audioUrl: url,
                        videoUrl: isVideo ? url : undefined,
                        key: "Auto",
                        bpm: 120,
                        lyrics: (window as any)._pendingLyrics || [{ time: 0, text: "Begin performance..." }]
                      };
                      if ((window as any)._pendingLyrics) (window as any)._pendingLyrics = null;
                      onSelect(localSong);
                    }
                  }}
                />
              </label>

              <label className="flex items-center justify-center gap-2 bg-brand-surface border border-brand-border border-dashed rounded-lg py-2.5 px-3 text-[10px] font-bold text-cyan-400 hover:border-cyan-400/50 hover:bg-cyan-400/5 cursor-pointer transition-all">
                <Plus className="w-3.5 h-3.5" />
                <span>Load .LRC</span>
                <input 
                  type="file" 
                  accept=".lrc" 
                  className="hidden" 
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        const content = event.target?.result as string;
                        const lines = content.split('\n');
                        const parsedLyrics = lines.map(line => {
                          const match = line.match(/\[(\d+):(\d+\.\d+)\](.*)/);
                          if (match) {
                            const minutes = parseInt(match[1]);
                            const seconds = parseFloat(match[2]);
                            return { time: minutes * 60 + seconds, text: match[3].trim() };
                          }
                          return null;
                        }).filter(l => l !== null) as {time: number, text: string}[];

                        if (parsedLyrics.length > 0) {
                          alert(`Loaded ${parsedLyrics.length} lyric lines. Select a media file now to pair them.`);
                          (window as any)._pendingLyrics = parsedLyrics;
                        }
                      };
                      reader.readAsText(file);
                    }
                  }}
                />
              </label>
            </div>
          </div>

          <div className="flex flex-col gap-2 flex-1">
            <span className="text-[10px] font-black uppercase text-brand-dim tracking-widest ml-1">Stream Link</span>
            <div className="relative group">
              <input 
                id="custom-url-input"
                type="text"
                placeholder="YouTube or URL..."
                className="w-full bg-brand-surface border border-brand-border rounded-lg py-2.5 pl-4 pr-24 text-[11px] font-mono focus:outline-none focus:border-brand-accent transition-all text-white placeholder:text-brand-dim/50 shadow-inner"
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
              />
              <button 
                onClick={handleCustomLoad}
                className="absolute right-1.5 top-1.5 bottom-1.5 px-3 bg-brand-accent hover:bg-brand-accent/90 text-[10px] font-black uppercase rounded shadow-lg transition-transform active:scale-95 text-white"
              >
                Load
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((song) => (
          <motion.div 
            key={song.id}
            whileHover={{ y: -4, borderColor: "rgba(79,70,229,0.4)" }}
            className="bg-brand-surface p-6 rounded-xl border border-brand-border transition-all group cursor-pointer relative overflow-hidden"
            onClick={() => onSelect(song)}
          >
            <div className="flex items-start justify-between relative z-10">
              <div className="flex flex-col gap-1">
                <span className="text-[10px] font-black uppercase text-brand-accent tracking-[0.2em]">{song.genre}</span>
                <h3 className="text-lg font-bold leading-tight text-white">{song.title}</h3>
                <p className="text-xs text-brand-dim font-serif italic">{song.artist}</p>
              </div>
              <button className="w-10 h-10 flex items-center justify-center bg-brand-bg rounded-lg border border-brand-border group-hover:bg-brand-accent group-hover:border-brand-accent group-hover:text-white transition-all text-brand-dim">
                <Play className="w-4 h-4 ml-0.5" />
              </button>
            </div>
            
            <div className="mt-6 flex items-center gap-4 text-[10px] font-bold text-brand-dim relative z-10 uppercase tracking-widest border-t border-brand-border pt-4">
              <div className="flex items-center gap-1.5"><Mic2 className="w-3 h-3 text-brand-accent" /> {song.key}</div>
              <div className="flex items-center gap-1.5"><Music className="w-3 h-3 text-brand-accent" /> {song.bpm} BPM</div>
            </div>

            <div className="absolute -right-6 -bottom-6 opacity-[0.02] group-hover:opacity-[0.05] transition-opacity">
               <Mic2 className="w-24 h-24 rotate-12" />
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
