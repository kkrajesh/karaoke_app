import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fetch from "node-fetch";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Audio/Video Proxy Route to bypass CORS
  app.get("/api/proxy-audio", async (req, res) => {
    const mediaUrl = req.query.url as string;
    
    if (!mediaUrl) {
      return res.status(400).send("Missing url parameter");
    }

    try {
      console.log("Proxy: Requesting resource:", mediaUrl);
      
      const headers: Record<string, string> = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      };

      if (req.headers.range) {
        headers["Range"] = req.headers.range;
        console.log("Proxy: Forwarding Range header:", req.headers.range);
      }

      console.log(`Proxy: Forwarding ${req.method} request to: ${mediaUrl}`);
      
      const response = await fetch(mediaUrl, { 
        method: req.method,
        headers,
        redirect: 'follow',
        compress: false
      });
      
      console.log(`Proxy: Remote response: ${response.status} ${response.statusText} (${mediaUrl})`);
      
      // Handle non-success statuses from remote
      if (response.status >= 400) {
        console.warn(`Proxy: Remote server returned error ${response.status}`);
        return res.status(response.status).send(`Remote server returned error: ${response.statusText}`);
      }

      // Headers to forward
      const headersToForward = [
        "content-type",
        "content-length",
        "content-range",
        "accept-ranges",
        "cache-control",
        "last-modified",
        "etag"
      ];

      // Important: set status first
      res.status(response.status);
      
      headersToForward.forEach(h => {
        const val = response.headers.get(h);
        if (val) {
          res.setHeader(h, val);
        }
      });

      // Override/Set CORS
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
      res.setHeader("Access-Control-Allow-Headers", "*");
      res.setHeader("Access-Control-Expose-Headers", "Content-Range, Content-Length, Accept-Ranges");
      
      // Safety: if it's head request, we are done
      if (req.method === "OPTIONS") {
        return res.sendStatus(200);
      }
      
      if (req.method === "HEAD" || !response.body) {
        return res.end();
      }

      // Pipe the body stream
      response.body.pipe(res);
      
      // Cleanup on disconnect
      const cleanup = () => {
        if (response.body && (response.body as any).destroy) {
          (response.body as any).destroy();
        }
      };

      req.on("close", cleanup);
      req.on("end", cleanup);
      
      response.body.on("error", (err) => {
        console.error("Proxy: Stream error:", err);
        if (!res.headersSent) res.status(500).send("Stream error");
        cleanup();
      });

    } catch (error) {
      console.error("Proxy error:", error);
      if (!res.headersSent) res.status(500).send("Error fetching media resource");
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
