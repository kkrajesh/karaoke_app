# Vokal - Professional Studio & Karaoke Engine

Vokal is a high-density, professional-grade vocal performance suite designed for singers, musicians, and performers. It combines real-time digital signal processing (DSP) with AI-driven insights to provide a complete studio experience in the browser.

## 🚀 Tech Stack

- **Framework**: React 18 (Vite)
- **Language**: TypeScript
- **Audio Engine**: [Tone.js](https://tonejs.github.io/) for advanced DSP, Pitch Shifting, and Analysis.
- **AI Engine**: [Google Gemini 2.0 Flash](https://ai.google.dev/) for intelligent medley calibration and song recommendations.
- **Backend**: Express.js (serving as a CORS bypass proxy and production server).
- **Database & Auth**: Firebase (Firestore & Authentication).
- **Styling**: Tailwind CSS (High-Density Theme).
- **Visualization**: Recharts & Motion (formerly Framer Motion) for real-time vocal precision graphs.
- **External Integration**: `react-player` for seamless YouTube and multi-source streaming.

## ✨ Built Features

### 1. Advanced Studio Player
- **Dual Engine Architecture**: Seamlessly switches between a local Tone.js buffer player (for file-based tracks) and `react-player` for YouTube.
- **Local Studio Upload**: Broadcast your own instrumentals directly from your laptop. This enables high-fidelity **Tone.js Pitch Shifting** and real-time DSP that YouTube streams often restrict.
- **Micro-Pitch Adjustments**: Shift pitch by 0.5 semitone increments with millisecond accuracy (local tracks only).
- **Tempo Calibration**: Fluid time-stretching without frequency distortion.
- **Arrangement Markers**: Instant navigation through song sections (Verse, Chorus, Bridge).

### 2. Real-Time Vocal Analysis
- **Pitch Detection**: Integrated autocorrelation algorithm analyzing microphone input in real-time.
- **Precision Visualization**: A dynamic accuracy graph comparing live performance against target midi notes.
- **Low-Latency Monitoring**: Direct microphone-to-analyzer pipeline for immediate feedback.

### 3. AI Medley Engine
- **Gemini Recommendations**: One-tap "Generate Medley" uses AI to analyze current Key, BPM, and Genre to suggest 5 perfectly compatible follow-up tracks.
- **Smart Transitions**: Suggested tracks are calibrated for smooth energy transitions.

### 4. Open-Source Library & Custom Import
- **Curated Archive**: Pre-loaded master tracks with synced lyrics data.
- **Custom URL Support**: Paste any YouTube link or direct audio URL to sing over external sources.
- **CORS Proxy**: Automated backend proxying allows for loading external assets that would normally be blocked by cross-origin policies.

### 5. High-Density Aesthetic
- **VoxPro Studio Theme**: A technical, dark-mode interface designed for focus and precision.
- **Sidebar Workflow**: Optimized navigation for library, community, and personal activity.

## 🗺️ Planned Features

- **Performance Recording**: Capturing master output + vocal input into a single high-quality audio file.
- **Cloud Storage**: Persistent storage for recordings via Firebase Storage.
- **Vocal FX Suite**: Studio-grade Reverb, Delay, and Compression controls.
- **Community Feed**: A "Global Stage" to share and upvote performances.
- **Advanced Scoring**: A comprehensive 100-point accuracy score based on pitch and rhythmic timing.
- **Dynamic Lyics Sync**: An AI-powered tool to auto-generate lyrics timestamps for custom uploaded tracks.
- **Time-Segmented Playback**: Ability to play specific segments of a video or audio file based on predefined time slots or markers.

## 🛠️ Performance Notes

- **Microphone Permissions**: The app requires microphone access for vocal analysis features.
- **YouTube Limitations**: Note that Google's security policies prevent direct pitch-shifting of YouTube audio streams. For tracks requiring pitch adjustment, use direct audio URLs or pre-loaded library tracks.
- **CORS Handling**: For cross-origin audio files, the service automatically routes requests through `/api/proxy-audio` to ensure consistent playback.
